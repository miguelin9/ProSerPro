var fs = require('fs');
var uno = require('./uno.js');

var datos = fs.readFile('examen1B.json',(err, data) => {
	 if (err) throw err;
	 var equipos = JSON.parse(data);
	 var coleccion = uno(equipos);
	 console.log("---IP---");
	 console.log(coleccion.numeroEquipos(44));
	 console.log("---MAC---");
	 console.log(coleccion.equipo("8E-6E-B9-83-C4-64"));
	 console.log("---DOMINIO---");
	 console.log(coleccion.array("com"));
});
