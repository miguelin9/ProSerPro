module.exports = function(coleccion){
    _coleccion = coleccion;
    return{
        numeroEquipos : function (ip){
            var contador = 0;
            for (var i = 0; i < _coleccion.length; i++) {
                if (_coleccion[i].ip_address = /^ip/) {
                    contador++;
                }
            }
            return "Equipos que empieza su ip por "+ip+": "+contador;
        },
        equipo        : function (mac){
            for (var i = 0; i < _coleccion.length; i++) {
                if (_coleccion[i].mac === mac) {
                    return _coleccion[i];
                }
            }
            return "Equipo no encontrado";
        },
        array         : function (dominio){
            var equiposDominio = [];
            for (var i = 0; i < _coleccion.length; i++) {
                var datos = _coleccion[i].host.split(".");
                if (datos[1]===dominio) {
                    equiposDominio.push(_coleccion[i]);
                }
            }
            return equiposDominio;
        }
    }
}
