var mongoose = require('mongoose');
var conexion = mongoose.connect('mongodb://localhost/examen');
var Schema = mongoose.Schema;

var equipoSchema = new Schema({
    host : String,
    mac : String,
    ip_address : String
});

var Equipo = mongoose.model('Computers', equipoSchema);

module.exports=Equipo;
