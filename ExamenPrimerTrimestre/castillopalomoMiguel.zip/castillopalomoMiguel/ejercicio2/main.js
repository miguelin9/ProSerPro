var express = require('express');
var app = express();

app.get("/mac/:mac", (req, res) {
    //var mac = req.params.mac;
});

app.post("/", (req, res){

});

app.listen(3000, () => console.log('escuchando en puerto 3000'));
